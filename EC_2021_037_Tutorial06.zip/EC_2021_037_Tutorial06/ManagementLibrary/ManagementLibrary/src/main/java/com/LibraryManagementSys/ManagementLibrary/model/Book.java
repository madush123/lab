package com.LibraryManagementSys.ManagementLibrary.model;


import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "books")
public class Book {

    @Id
    private String id;

    private String title;
    private String author;
    private String category;
    private double price;
    private int stock;

    public Book() {}

    public Book(String title, String author, String category, double price, int stock) {
        this.title = title;
        this.author = author;
        this.category = category;
        this.price = price;
        this.stock = stock;
    }

    // Getters & Setters

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public Object getPublicationYear() {
        throw new UnsupportedOperationException("Unimplemented method 'getPublicationYear'");
    }

    public void setPublicationYear(Object publicationYear) {
        throw new UnsupportedOperationException("Unimplemented method 'setPublicationYear'");
    }

    public Object getGenre() {
        throw new UnsupportedOperationException("Unimplemented method 'getGenre'");
    }

    public void setGenre(Object genre) {
        throw new UnsupportedOperationException("Unimplemented method 'setGenre'");
    }
}
