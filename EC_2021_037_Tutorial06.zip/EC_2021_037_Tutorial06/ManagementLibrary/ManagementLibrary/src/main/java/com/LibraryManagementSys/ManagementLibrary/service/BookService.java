package com.LibraryManagementSys.ManagementLibrary.service;

import com.LibraryManagementSys.ManagementLibrary.model.Book;

import java.util.List;
import java.util.Optional;

public interface BookService {

    // Add a new book
    Book addBook(Book book);

    // Retrieve all books
    List<Book> getAllBooks();

    // Fetch a book by its ID
    Optional<Book> getBookById(String id);

    // Update book details
    Book updateBook(String id, Book book);

    // Delete a book by its ID
    void deleteBookById(String id);

    // Find books by publication year
    List<Book> findBooksByPublicationYear(int year);

    // Get the genre of a specific book by its ID
    String getGenreByBookId(String id);

    // Delete all books published in a specific year
    void deleteBooksByPublicationYear(int year);
}
