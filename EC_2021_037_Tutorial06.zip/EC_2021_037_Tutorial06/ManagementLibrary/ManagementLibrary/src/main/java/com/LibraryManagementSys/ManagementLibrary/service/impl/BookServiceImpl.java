package com.LibraryManagementSys.ManagementLibrary.service.impl;


import com.LibraryManagementSys.ManagementLibrary.model.Book;
import com.LibraryManagementSys.ManagementLibrary.repository.BookRepository;
import com.LibraryManagementSys.ManagementLibrary.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BookServiceImpl implements BookService {

    @Autowired
    private BookRepository bookRepository;

    @Override
    public Book addBook(Book book) {
        return bookRepository.save(book);
    }

    @Override
    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }

    @Override
    public Optional<Book> getBookById(String id) {
        return bookRepository.findById(id);
    }

    @Override
    public Book updateBook(String id, Book updatedBook) {
        Optional<Book> existingBookOpt = bookRepository.findById(id);

        if (existingBookOpt.isEmpty()) {
            return null;
        }

        Book existingBook = existingBookOpt.get();

        existingBook.setTitle(updatedBook.getTitle());
        existingBook.setAuthor(updatedBook.getAuthor());
        existingBook.setCategory(updatedBook.getCategory());
        existingBook.setPrice(updatedBook.getPrice());
        existingBook.setStock(updatedBook.getStock());
        existingBook.setPublicationYear(updatedBook.getPublicationYear());
        existingBook.setGenre(updatedBook.getGenre());

        return bookRepository.save(existingBook);
    }

    @Override
    public void deleteBookById(String id) {
        bookRepository.deleteById(id);
    }

    @Override
    public List<Book> findBooksByPublicationYear(int year) {
        return bookRepository.findByPublicationYear(year);
    }

    @Override
    public String getGenreByBookId(String id) {
        Optional<Book> book = bookRepository.findById(id);
        return (String) book.map(Book::getGenre).orElse(null);
    }

    @Override
    public void deleteBooksByPublicationYear(int year) {
        bookRepository.deleteByPublicationYear(year);
    }
}
