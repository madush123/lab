package com.LibraryManagementSys.ManagementLibrary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManagementLibraryApplicationTests {

	@Test
	void contextLoads() {
	}

}
